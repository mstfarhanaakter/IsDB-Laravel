<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Department Details</h1>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <?php echo e($department->name); ?>

        </div>
        <div class="card-body">
            <p><strong>Description:</strong> <?php echo e($department->description ?? 'No description available.'); ?></p>
            <p><strong>Created At:</strong> <?php echo e($department->created_at->format('d M, Y H:i')); ?></p>
            <p><strong>Updated At:</strong> <?php echo e($department->updated_at->format('d M, Y H:i')); ?></p>
        </div>
    </div>

    <div class="mt-3">
        <a href="<?php echo e(route('departments.edit', $department)); ?>" class="btn btn-warning">Edit</a>
        <a href="<?php echo e(route('departments.index')); ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\departments\show.blade.php ENDPATH**/ ?>