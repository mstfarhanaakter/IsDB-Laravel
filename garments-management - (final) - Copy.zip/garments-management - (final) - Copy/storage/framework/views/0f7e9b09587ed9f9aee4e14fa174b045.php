<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Product Details</h2>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary mb-3">Back to Products</a>

    <div class="card p-4">
        <h4>Name: <?php echo e($product->name); ?></h4>
        <p><strong>Category:</strong> <?php echo e($product->category->name ?? '-'); ?></p>
        <p><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
        <p><strong>Stock Quantity:</strong> <?php echo e($product->stock_quantity); ?></p>
        <p><strong>Description:</strong> <?php echo e($product->description ?? 'No Description'); ?></p>

        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning">Edit</a>
        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\products\show.blade.php ENDPATH**/ ?>