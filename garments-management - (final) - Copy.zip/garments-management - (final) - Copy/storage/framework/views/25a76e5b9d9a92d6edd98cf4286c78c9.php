<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 text-gray-800">Defect Details</h1>
        <a href="<?php echo e(route('production_defects.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-borderless">
                <tr>
                    <th>Production Line:</th>
                    <td><?php echo e($productionDefect->productionLine->name ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Order No:</th>
                    <td><?php echo e($productionDefect->order->order_number ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Defect Type:</th>
                    <td><?php echo e($productionDefect->defect_type); ?></td>
                </tr>
                <tr>
                    <th>Defect Qty:</th>
                    <td><?php echo e($productionDefect->defect_qty); ?></td>
                </tr>
                <tr>
                    <th>Reported By:</th>
                    <td><?php echo e($productionDefect->reported_by ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Description:</th>
                    <td><?php echo e($productionDefect->description ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Status:</th>
                    <td>
                        <?php if($productionDefect->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php elseif($productionDefect->status == 'reworked'): ?>
                            <span class="badge bg-info text-dark">Reworked</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Scrapped</span>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\production_defects\show.blade.php ENDPATH**/ ?>