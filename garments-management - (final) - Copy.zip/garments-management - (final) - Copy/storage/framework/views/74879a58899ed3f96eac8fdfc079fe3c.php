<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Purchases</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-primary mb-3">Add New Purchase</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Supplier</th>
                <th>Material</th>
                <th>Purchase Date</th>
                <th>Total Amount</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($purchase->id); ?></td>
                    <td><?php echo e($purchase->supplier ? $purchase->supplier->name : 'No Supplier'); ?></td>
                    <td><?php echo e($purchase->material ? $purchase->material->name : 'No Material'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y')); ?></td>
                    <td><?php echo e(number_format($purchase->total_amount, 2)); ?></td>
                    <td>
                        <a href="<?php echo e(route('purchases.show', $purchase->id)); ?>" class="btn btn-sm btn-info">View</a>
                        <a href="<?php echo e(route('purchases.edit', $purchase->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('purchases.destroy', $purchase->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this purchase?')">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">No purchases found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\purchases\index.blade.php ENDPATH**/ ?>