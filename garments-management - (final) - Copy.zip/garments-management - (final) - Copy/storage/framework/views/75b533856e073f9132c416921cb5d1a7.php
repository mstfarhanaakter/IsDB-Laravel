<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Edit Attendance</h2>

    <form action="<?php echo e(route('attendances.update', $attendance->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">

            <div class="col-md-6 mb-3">
                <label>Employee *</label>
                <select name="employee_id" class="form-control" required>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" 
                            <?php echo e($attendance->employee_id == $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-6 mb-3">
                <label>Date *</label>
                <input type="date" name="date" class="form-control" value="<?php echo e($attendance->date); ?>" required>
            </div>

            <div class="col-md-6 mb-3">
                <label>Status *</label>
                <select name="status" class="form-control" required>
                    <option value="Present" <?php echo e($attendance->status=='Present'?'selected':''); ?>>Present</option>
                    <option value="Absent" <?php echo e($attendance->status=='Absent'?'selected':''); ?>>Absent</option>
                    <option value="Leave" <?php echo e($attendance->status=='Leave'?'selected':''); ?>>Leave</option>
                </select>
            </div>

        </div>

        <button class="btn btn-success mt-3">Update Attendance</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\attendances\edit.blade.php ENDPATH**/ ?>