

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Generate Salary Sheet</h2>

    <form action="<?php echo e(route('salaries.generate')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Month</label>
            <select name="month" class="form-select" required>
                <?php $__currentLoopData = ['January','February','March','April','May','June','July','August','September','October','November','December']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m); ?>"><?php echo e($m); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Year</label>
            <input type="number" name="year" class="form-control" value="<?php echo e(date('Y')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Generate Salary</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\salaries\create.blade.php ENDPATH**/ ?>