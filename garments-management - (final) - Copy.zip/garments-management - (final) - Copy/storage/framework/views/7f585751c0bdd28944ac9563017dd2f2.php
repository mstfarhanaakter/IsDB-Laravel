<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Purchase Details #<?php echo e($purchase->id); ?></h1>

    <div class="card">
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($purchase->id); ?></p>
            <p><strong>Supplier:</strong> <?php echo e($purchase->supplier ? $purchase->supplier->name : 'N/A'); ?></p>
            <p><strong>Material:</strong> <?php echo e($purchase->material ? $purchase->material->name : 'N/A'); ?></p>
            <p><strong>Purchase Date:</strong> <?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y')); ?></p>
            <p><strong>Total Amount:</strong> <?php echo e(number_format($purchase->total_amount, 2)); ?></p>
            <p><strong>Created At:</strong> <?php echo e($purchase->created_at->format('d M Y, H:i')); ?></p>
            <p><strong>Updated At:</strong> <?php echo e($purchase->updated_at->format('d M Y, H:i')); ?></p>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('purchases.edit', $purchase->id)); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-secondary">Back to List</a>

            <form action="<?php echo e(route('purchases.destroy', $purchase->id)); ?>" method="POST" style="display:inline-block;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this purchase?')">
                    Delete
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\purchases\show.blade.php ENDPATH**/ ?>