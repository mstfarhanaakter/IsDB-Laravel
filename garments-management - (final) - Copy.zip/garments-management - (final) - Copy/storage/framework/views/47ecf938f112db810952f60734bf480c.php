<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="card shadow-sm border-0">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0">Employee List</h3>

                <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add Employee
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th width="50">ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($employee->id); ?></td>
                                <td class="fw-semibold"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td>
                                    <span class="badge bg-info text-dark">
                                        <?php echo e($employee->department->name ?? 'N/A'); ?>

                                    </span>
                                </td>
                                <td><?php echo e($employee->position); ?></td>

                                <td>
                                    <a href="<?php echo e(route('employees.show', $employee->id)); ?>" 
                                       class="btn btn-sm btn-outline-info">
                                        View
                                    </a>

                                    <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" 
                                       class="btn btn-sm btn-outline-warning">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>"
                                          method="POST"
                                          class="d-inline"
                                          onsubmit="return confirm('Are you sure you want to delete this employee?')">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button class="btn btn-sm btn-outline-danger" type="submit">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">
                                    No employees found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\employees\index.blade.php ENDPATH**/ ?>