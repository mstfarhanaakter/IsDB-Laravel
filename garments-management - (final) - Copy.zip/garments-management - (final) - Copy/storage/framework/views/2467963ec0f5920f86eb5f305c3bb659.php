<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb‑4">Add New Purchase</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('purchases.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb‑3">
            <label for="supplier_id" class="form-label">Supplier</label>
            <select name="supplier_id" id="supplier_id" class="form-select" required>
                <option value="">Select Supplier</option>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($supplier->id); ?>"
                    <?php echo e(old('supplier_id') == $supplier->id ? 'selected' : ''); ?>>
                    <?php echo e($supplier->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb‑3">
            <label for="material_id" class="form-label">Material</label>
            <select name="material_id" id="material_id" class="form-select" required>
                <option value="">Select Material</option>
                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($material->id); ?>"
                    <?php echo e(old('material_id') == $material->id ? 'selected' : ''); ?>>
                    <?php echo e($material->name); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb‑3">
            <label for="purchase_date" class="form-label">Purchase Date</label>
            <input type="date" name="purchase_date" id="purchase_date"
                   class="form-control" value="<?php echo e(old('purchase_date')); ?>" required>
        </div>

        <div class="mb‑3">
            <label for="total_amount" class="form-label">Total Amount</label>
            <input type="number" step="0.01" name="total_amount" id="total_amount"
                   class="form-control" value="<?php echo e(old('total_amount', 0)); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Create Purchase</button>
        <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-secondary">Back to List</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\purchases\create.blade.php ENDPATH**/ ?>