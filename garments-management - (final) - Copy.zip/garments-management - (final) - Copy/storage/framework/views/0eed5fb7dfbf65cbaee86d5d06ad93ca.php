

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Salary — <?php echo e($salary->employee->full_name); ?></h2>

    <form action="<?php echo e(route('salaries.update',$salary->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Basic</label>
            <input type="number" name="basic" class="form-control" value="<?php echo e($salary->basic); ?>" step="0.01" required>
        </div>

        <div class="mb-3">
            <label>House Rent</label>
            <input type="number" name="house_rent" class="form-control" value="<?php echo e($salary->house_rent); ?>" step="0.01" required>
        </div>

        <div class="mb-3">
            <label>Medical</label>
            <input type="number" name="medical" class="form-control" value="<?php echo e($salary->medical); ?>" step="0.01" required>
        </div>

        <div class="mb-3">
            <label>Transport</label>
            <input type="number" name="transport" class="form-control" value="<?php echo e($salary->transport); ?>" step="0.01" required>
        </div>

        <div class="mb-3">
            <label>Overtime</label>
            <input type="number" name="overtime_amount" class="form-control" value="<?php echo e($salary->overtime_amount); ?>" step="0.01">
        </div>

        <div class="mb-3">
            <label>Absent Deduction</label>
            <input type="number" name="absent_deduction" class="form-control" value="<?php echo e($salary->absent_deduction); ?>" step="0.01">
        </div>

        <button type="submit" class="btn btn-primary">Update Salary</button>
        <a href="<?php echo e(route('salaries.index')); ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\salaries\edit.blade.php ENDPATH**/ ?>