<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Category Details</h2>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary mb-3">Back to Categories</a>

    <div class="card p-4">
        <h4 class="mb-3">Name: <?php echo e($category->name); ?></h4>

        <div class="mb-3">
            <strong>Image:</strong>
            <div class="mt-2">
                <?php if($category->image): ?>
                    <img src="<?php echo e(asset('uploads/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>" width="200" class="img-thumbnail">
                <?php else: ?>
                    <span class="text-muted">No Image</span>
                <?php endif; ?>
            </div>
        </div>

        <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning">Edit</a>
        <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure you want to delete this category?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\categories\show.blade.php ENDPATH**/ ?>