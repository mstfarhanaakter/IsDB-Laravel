

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Employee Salary</h2>

    <form action="<?php echo e(route('employee-salaries.update', $employeeSalary->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-2">
            <label>Employee</label>
            <select name="employee_id" class="form-control" required>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>" <?php echo e($employeeSalary->employee_id == $employee->id ? 'selected' : ''); ?>>
                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mb-2">
            <label>Month</label>
            <select name="month" class="form-control" required>
                <?php for($i=1; $i<=12; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e($employeeSalary->month == $i ? 'selected' : ''); ?>>
                        <?php echo e(\Carbon\Carbon::createFromDate(null, $i, 1)->format('F')); ?>

                    </option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group mb-2">
            <label>Year</label>
            <input type="number" name="year" class="form-control" value="<?php echo e($employeeSalary->year); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Basic</label>
            <input type="number" step="0.01" name="basic" class="form-control" value="<?php echo e($employeeSalary->basic); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>House Rent</label>
            <input type="number" step="0.01" name="house_rent" class="form-control" value="<?php echo e($employeeSalary->house_rent); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Medical</label>
            <input type="number" step="0.01" name="medical" class="form-control" value="<?php echo e($employeeSalary->medical); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Transport</label>
            <input type="number" step="0.01" name="transport" class="form-control" value="<?php echo e($employeeSalary->transport); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Overtime Amount</label>
            <input type="number" step="0.01" name="overtime_amount" class="form-control" value="<?php echo e($employeeSalary->overtime_amount); ?>">
        </div>

        <div class="form-group mb-2">
            <label>Absent Deduction</label>
            <input type="number" step="0.01" name="absent_deduction" class="form-control" value="<?php echo e($employeeSalary->absent_deduction); ?>">
        </div>

        <div class="form-group mb-2">
            <label>Gross Salary</label>
            <input type="number" step="0.01" name="gross_salary" class="form-control" value="<?php echo e($employeeSalary->gross_salary); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label>Net Salary</label>
            <input type="number" step="0.01" name="net_salary" class="form-control" value="<?php echo e($employeeSalary->net_salary); ?>" required>
        </div>

        <button class="btn btn-success mt-2">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\employee_salaries\edit.blade.php ENDPATH**/ ?>