<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Production Line Details</h1>
    <a href="<?php echo e(route('production-lines.index')); ?>" class="btn btn-secondary mb-3">Back</a>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($productionLine->name); ?></h5>
            <p class="card-text"><strong>Description:</strong> <?php echo e($productionLine->description); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\production_lines\show.blade.php ENDPATH**/ ?>