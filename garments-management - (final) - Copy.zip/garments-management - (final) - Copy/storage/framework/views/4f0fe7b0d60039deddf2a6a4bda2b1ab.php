<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="mb-0">Purchase Items</h1>
        <a href="<?php echo e(route('purchase-items.create')); ?>" class="btn btn-primary">Add Purchase Item</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="table-responsive shadow-sm rounded">
        <table class="table table-striped table-bordered align-middle text-center mb-0">
            <thead class="table-dark text-uppercase">
                <tr>
                    <th>#</th>
                    <th>Material</th>
                    <th>Supplier</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $statusClass = match($item->status) {
                            'pending' => 'bg-warning text-dark',
                            'approved' => 'bg-success text-white',
                            'rejected' => 'bg-danger text-white',
                            default => 'bg-secondary text-white'
                        };
                    ?>
                    <tr>
                        <td class="fw-bold"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->material->name); ?></td>
                        <td><?php echo e($item->supplier->name); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e(number_format($item->unit_price, 2)); ?></td>
                        <td><?php echo e(number_format($item->total, 2)); ?></td>
                        <td>
                            <span class="badge <?php echo e($statusClass); ?> px-3 py-2 rounded-pill">
                                <?php echo e(ucfirst($item->status)); ?>

                            </span>
                        </td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <a href="<?php echo e(route('purchase-items.show', $item)); ?>" class="btn btn-info btn-sm shadow-sm">View</a>
                                <a href="<?php echo e(route('purchase-items.edit', $item)); ?>" class="btn btn-warning btn-sm shadow-sm">Edit</a>
                                <form action="<?php echo e(route('purchase-items.destroy', $item)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm shadow-sm" onclick="return confirm('Are you sure?')">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center fw-semibold">No purchase items found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\purchase_items\index.blade.php ENDPATH**/ ?>