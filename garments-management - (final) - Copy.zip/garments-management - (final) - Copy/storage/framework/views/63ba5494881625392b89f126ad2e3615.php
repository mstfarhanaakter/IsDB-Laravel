<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Material Details</h1>

    <div class="card">
        <div class="card-header">
            <strong><?php echo e($material->name); ?></strong>
        </div>
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($material->id); ?></p>
            <p><strong>Unit:</strong> <?php echo e($material->unit); ?></p>
            <p><strong>Current Stock:</strong> <?php echo e($material->current_stock); ?></p>
            <p><strong>Supplier:</strong> <?php echo e($material->supplier ? $material->supplier->name : 'No Supplier'); ?></p>
            <p><strong>Created At:</strong> <?php echo e($material->created_at->format('d M Y, H:i')); ?></p>
            <p><strong>Updated At:</strong> <?php echo e($material->updated_at->format('d M Y, H:i')); ?></p>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('materials.edit', $material->id)); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(route('materials.index')); ?>" class="btn btn-secondary">Back</a>

            <form action="<?php echo e(route('materials.destroy', $material->id)); ?>" method="POST" style="display:inline-block;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\materials\show.blade.php ENDPATH**/ ?>