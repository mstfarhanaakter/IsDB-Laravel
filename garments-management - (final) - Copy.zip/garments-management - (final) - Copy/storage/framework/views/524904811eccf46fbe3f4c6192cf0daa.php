<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1 class="mb-4">Purchase Orders & Items</h1>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="table-responsive shadow-sm rounded">
        <table class="table table-striped table-bordered text-center align-middle mb-0">
            <thead class="table-dark text-uppercase">
                <tr>
                    <th scope="col">Order ID</th>
                    <th scope="col">Supplier</th>
                    <th scope="col">Items</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle">
                        <td class="fw-bold"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($order->supplier->name); ?></td>
                        <td class="p-0">
                            
                            <table class="table table-borderless mb-0 table-sm">
                                <thead>
                                    <tr class="table-secondary text-center">
                                        <th>Material</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $itemStatusClass = match($item->status) {
                                                'pending' => 'bg-warning text-dark',
                                                'approved' => 'bg-success text-white',
                                                'rejected' => 'bg-danger text-white',
                                                default => 'bg-secondary text-white'
                                            };
                                        ?>
                                        <tr class="text-center align-middle">
                                            <td class="fw-semibold"><?php echo e($item->material->name); ?></td>
                                            <td><?php echo e($item->quantity); ?></td>
                                            <td>
                                                <span class="badge <?php echo e($itemStatusClass); ?> px-3 py-2 rounded-pill">
                                                    <?php echo e(ucfirst($item->status)); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('purchase-items.edit', $item->id)); ?>" 
                                                   class="btn btn-sm btn-primary shadow-sm">
                                                    Edit
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\purchase_orders\index.blade.php ENDPATH**/ ?>