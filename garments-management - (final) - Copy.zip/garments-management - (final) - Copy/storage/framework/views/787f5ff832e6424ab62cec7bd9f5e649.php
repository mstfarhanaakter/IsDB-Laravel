<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Order Details</h1>

    <div class="card">
        <div class="card-body">
            <h5>Order Number: <strong><?php echo e($order->order_number); ?></strong></h5>
            <p><strong>Buyer:</strong> <?php echo e($order->buyer->name ?? 'N/A'); ?></p>
            <p><strong>Order Date:</strong> <?php echo e($order->order_date); ?></p>
            <p><strong>Delivery Date:</strong> <?php echo e($order->delivery_date ?? '-'); ?></p>
            <p><strong>Total Quantity:</strong> <?php echo e($order->total_qty); ?></p>
            <p><strong>Status:</strong> <span class="badge bg-info text-dark"><?php echo e(ucfirst($order->status)); ?></span></p>
            <p><strong>Created At:</strong> <?php echo e($order->created_at->format('Y-m-d H:i')); ?></p>
            <p><strong>Last Updated:</strong> <?php echo e($order->updated_at->format('Y-m-d H:i')); ?></p>
        </div>
    </div>

    <div class="mt-3">
        <a href="<?php echo e(route('orders.edit', $order)); ?>" class="btn btn-warning">Edit</a>
        <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary">Back</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\orders\show.blade.php ENDPATH**/ ?>