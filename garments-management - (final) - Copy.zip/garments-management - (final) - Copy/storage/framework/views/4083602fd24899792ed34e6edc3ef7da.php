

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Edit Leave Request</h2>

    <form action="<?php echo e(route('leave_requests.update', $leaveRequest->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">

            <div class="col-md-6 mb-3">
                <label>Employee *</label>
                <select name="employee_id" class="form-control" required>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" 
                            <?php echo e($leaveRequest->employee_id == $employee->id ? 'selected' : ''); ?>>
                            <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3 mb-3">
                <label>Start Date *</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e($leaveRequest->start_date); ?>" required>
            </div>

            <div class="col-md-3 mb-3">
                <label>End Date *</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e($leaveRequest->end_date); ?>" required>
            </div>

            <div class="col-md-12 mb-3">
                <label>Reason *</label>
                <textarea name="reason" class="form-control" rows="3" required><?php echo e($leaveRequest->reason); ?></textarea>
            </div>

            <div class="col-md-6 mb-3">
                <label>Status *</label>
                <select name="status" class="form-control" required>
                    <option value="Pending" <?php echo e($leaveRequest->status=='Pending'?'selected':''); ?>>Pending</option>
                    <option value="Approved" <?php echo e($leaveRequest->status=='Approved'?'selected':''); ?>>Approved</option>
                    <option value="Rejected" <?php echo e($leaveRequest->status=='Rejected'?'selected':''); ?>>Rejected</option>
                </select>
            </div>

        </div>

        <button class="btn btn-success mt-3">Update Leave Request</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\MasterCopy copy 5\edit.blade.php ENDPATH**/ ?>