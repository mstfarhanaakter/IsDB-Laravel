<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h1 class="mb-4 text-center">Buyers Orders Dashboard</h1>

    <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span><strong><?php echo e($buyer->name); ?></strong>'s Orders</span>
                <span class="badge bg-dark"><?php echo e($buyer->orders->count()); ?> Orders</span>
            </div>
            <div class="card-body p-0">
                <?php if($buyer->orders->count()): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Order No</th>
                                    <th>Order Date</th>
                                    <th>Delivery Date</th>
                                    <th>Total Quantity</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $buyer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($order->order_number); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d M, Y')); ?></td>
                                        <td><?php echo e($order->delivery_date ? \Carbon\Carbon::parse($order->delivery_date)->format('d M, Y') : '-'); ?></td>
                                        <td><?php echo e($order->total_qty); ?></td>
                                        <td>
                                            <?php switch($order->status):
                                                case ('pending'): ?>
                                                    <span class="badge bg-warning text-dark">Pending</span>
                                                    <?php break; ?>
                                                <?php case ('in_production'): ?>
                                                    <span class="badge bg-info text-dark">In Production</span>
                                                    <?php break; ?>
                                                <?php case ('completed'): ?>
                                                    <span class="badge bg-success">Completed</span>
                                                    <?php break; ?>
                                                <?php case ('delivered'): ?>
                                                    <span class="badge bg-secondary">Delivered</span>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <span class="badge bg-light text-dark">Unknown</span>
                                            <?php endswitch; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn btn-sm btn-primary">
                                                Edit Items
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="p-3 mb-0 text-muted text-center">This customer has no orders yet.</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\buyers\orders.blade.php ENDPATH**/ ?>