

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="card shadow-sm border-0">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0">Leave Requests</h3>
                <a href="<?php echo e(route('leave_requests.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add Leave Request
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th width="50">ID</th>
                            <th>Employee</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $leaveRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($leave->id); ?></td>
                                <td class="fw-semibold">
                                    <?php echo e($leave->employee->first_name ?? 'N/A'); ?> 
                                    <?php echo e($leave->employee->last_name ?? ''); ?>

                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($leave->start_date)->format('d M, Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($leave->end_date)->format('d M, Y')); ?></td>
                                <td><?php echo e($leave->reason); ?></td>
                                <td>
                                    <?php if($leave->status == 'Approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif($leave->status == 'Pending'): ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php elseif($leave->status == 'Rejected'): ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($leave->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('leave_requests.show', $leave->id)); ?>" 
                                       class="btn btn-sm btn-outline-info">View</a>
                                    <a href="<?php echo e(route('leave_requests.edit', $leave->id)); ?>" 
                                       class="btn btn-sm btn-outline-warning">Edit</a>

                                    <form action="<?php echo e(route('leave_requests.destroy', $leave->id)); ?>" 
                                          method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this leave request?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">No leave requests found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\MasterCopy copy 5\index.blade.php ENDPATH**/ ?>