<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 text-gray-800">Edit Production Defect</h1>
        <a href="<?php echo e(route('production_defects.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('production_defects.update', $productionDefect->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Production Line</label>
                        <select name="productions_line_id" class="form-select" required>
                            <?php $__currentLoopData = $productionLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($line->id); ?>" <?php echo e($productionDefect->productions_line_id == $line->id ? 'selected' : ''); ?>>
                                    <?php echo e($line->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Order</label>
                        <select name="order_id" class="form-select" required>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($order->id); ?>" <?php echo e($productionDefect->order_id == $order->id ? 'selected' : ''); ?>>
                                    <?php echo e($order->order_number); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Defect Type</label>
                        <input type="text" name="defect_type" class="form-control" value="<?php echo e($productionDefect->defect_type); ?>" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Defect Quantity</label>
                        <input type="number" name="defect_qty" class="form-control" value="<?php echo e($productionDefect->defect_qty); ?>" min="0" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Reported By</label>
                        <input type="text" name="reported_by" class="form-control" value="<?php echo e($productionDefect->reported_by); ?>">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Status</label>
                        <select name="status" class="form-select" required>
                            <option value="pending" <?php echo e($productionDefect->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="reworked" <?php echo e($productionDefect->status == 'reworked' ? 'selected' : ''); ?>>Reworked</option>
                            <option value="scrapped" <?php echo e($productionDefect->status == 'scrapped' ? 'selected' : ''); ?>>Scrapped</option>
                        </select>
                    </div>

                    <div class="col-12 mb-3">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo e($productionDefect->description); ?></textarea>
                    </div>

                    <div class="col-12 mb-3">
                        <label>Image</label>
                        <?php if($productionDefect->image_path): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('storage/'.$productionDefect->image_path)); ?>" class="img-thumbnail" width="120">
                            </div>
                        <?php endif; ?>
                        <input type="file" name="image_path" cla_

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\production_defects\edit.blade.php ENDPATH**/ ?>