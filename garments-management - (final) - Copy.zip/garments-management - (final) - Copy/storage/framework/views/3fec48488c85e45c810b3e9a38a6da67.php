<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="card shadow-sm border-0">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0">Attendance List</h3>
                <a href="<?php echo e(route('attendances.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add Attendance
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php elseif(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th width="50">ID</th>
                            <th>Employee</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($attendance->id); ?></td>
                                <td class="fw-semibold">
                                    <?php echo e($attendance->employee->first_name ?? 'N/A'); ?> 
                                    <?php echo e($attendance->employee->last_name ?? ''); ?>

                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($attendance->date)->format('d M, Y')); ?></td>
                                <td>
                                    <?php if($attendance->status == 'Present'): ?>
                                        <span class="badge bg-success">Present</span>
                                    <?php elseif($attendance->status == 'Absent'): ?>
                                        <span class="badge bg-danger">Absent</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($attendance->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('attendances.show', $attendance->id)); ?>" 
                                       class="btn btn-sm btn-outline-info">View</a>
                                    <a href="<?php echo e(route('attendances.edit', $attendance->id)); ?>" 
                                       class="btn btn-sm btn-outline-warning">Edit</a>

                                    <form action="<?php echo e(route('attendances.destroy', $attendance->id)); ?>" 
                                          method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this attendance?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No attendance records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\attendances\index.blade.php ENDPATH**/ ?>