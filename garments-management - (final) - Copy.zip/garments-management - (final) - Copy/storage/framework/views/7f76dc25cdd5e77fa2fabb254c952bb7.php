<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Supplier Details</h1>

    <div class="card">
        <div class="card-header">
            <?php echo e($supplier->name); ?>

        </div>
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($supplier->id); ?></p>
            <p><strong>Contact:</strong> <?php echo e($supplier->contact ?? '-'); ?></p>
            <p><strong>Email:</strong> <?php echo e($supplier->email ?? '-'); ?></p>
            <p><strong>Address:</strong> <?php echo e($supplier->address ?? '-'); ?></p>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('suppliers.edit', $supplier->id)); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\suppliers\show.blade.php ENDPATH**/ ?>