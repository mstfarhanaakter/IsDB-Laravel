

<?php $__env->startSection('content'); ?>
<div class="container mt-3">

    <div class="card shadow-sm border-0">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0">Employee Salaries</h3>
                <a href="<?php echo e(route('employee-salaries.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Add Salary
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Employee</th>
                            <th>Month</th>
                            <th>Year</th>
                            <th>Gross Salary</th>
                            <th>Net Salary</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="fw-semibold"><?php echo e($salary->employee->first_name); ?> <?php echo e($salary->employee->last_name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::createFromDate(null, $salary->month, 1)->format('F')); ?></td>
                                <td><?php echo e($salary->year); ?></td>
                                <td><?php echo e(number_format($salary->gross_salary, 2)); ?></td>
                                <td><?php echo e(number_format($salary->net_salary, 2)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('employee-salaries.show', $salary->id)); ?>" class="btn btn-sm btn-outline-info">View</a>
                                    <a href="<?php echo e(route('employee-salaries.edit', $salary->id)); ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                                    <form action="<?php echo e(route('employee-salaries.destroy', $salary->id)); ?>" 
                                          method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this salary?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">No salary records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\employee_salaries\index.blade.php ENDPATH**/ ?>