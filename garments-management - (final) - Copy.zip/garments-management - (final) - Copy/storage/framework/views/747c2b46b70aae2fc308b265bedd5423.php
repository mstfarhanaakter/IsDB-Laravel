<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>Delivery Details</h4>
        </div>
        <div class="card-body">
            <p><strong>Order No:</strong> <?php echo e($delivery->order->order_number); ?></p>
            <p><strong>Delivery Date:</strong> <?php echo e($delivery->delivery_date->format('d M, Y')); ?></p>
            <p><strong>Status:</strong> 
                <?php switch($delivery->status):
                    case ('pending'): ?>
                        <span class="badge bg-warning text-dark">Pending</span>
                        <?php break; ?>
                    <?php case ('on_the_way'): ?>
                        <span class="badge bg-info text-dark">On the Way</span>
                        <?php break; ?>
                    <?php case ('delivered'): ?>
                        <span class="badge bg-success">Delivered</span>
                        <?php break; ?>
                    <?php default: ?>
                        <span class="badge bg-light text-dark">Unknown</span>
                <?php endswitch; ?>
            </p>
            <a href="<?php echo e(route('deliveries.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\deliveries\show.blade.php ENDPATH**/ ?>