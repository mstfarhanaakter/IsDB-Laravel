<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Edit Category</h2>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary mb-3">Back to Categories</a>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card p-4">
        <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="name" class="form-label">Category Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $category->name)); ?>" required>
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Category Image</label>
                <input type="file" class="form-control" id="image" name="image">
                <?php if($category->image): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset('uploads/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>" width="120" class="img-thumbnail">
                    </div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-warning">Update Category</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\IsDB-Laravel\garments-management - (final) - Copy\resources\views\categories\edit.blade.php ENDPATH**/ ?>