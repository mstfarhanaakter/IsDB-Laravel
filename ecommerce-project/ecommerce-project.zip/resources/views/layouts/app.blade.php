@include('layouts.header')
@include('layouts.sidebar')
@include('layouts.mainContent')
@include('layouts.footer')