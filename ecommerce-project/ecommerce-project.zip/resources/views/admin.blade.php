@extends('layouts.app')
@section('content')
@include('layouts.navbar')
@include('layouts.dashboard')

@endsection