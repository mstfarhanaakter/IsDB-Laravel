
<?php $__env->startSection('title', 'Add Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="fw-bold text-white mb-4">Add New Product</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card bg-dark text-light shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="image" class="form-label">Product Image</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="4" required><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="mb-3 row">
                    <div class="col">
                        <label for="old_price" class="form-label">Old Price</label>
                        <input type="number" step="0.01" class="form-control" id="old_price" name="old_price" value="<?php echo e(old('old_price')); ?>">
                    </div>
                    <div class="col">
                        <label for="new_price" class="form-label">New Price</label>
                        <input type="number" step="0.01" class="form-control" id="new_price" name="new_price" value="<?php echo e(old('new_price')); ?>" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-3">
                    <i class="bi bi-plus-lg me-1"></i> Add Product
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LaravelProject\IsDB-Laravel\ecommerce-project - Copy\resources\views\products\create.blade.php ENDPATH**/ ?>