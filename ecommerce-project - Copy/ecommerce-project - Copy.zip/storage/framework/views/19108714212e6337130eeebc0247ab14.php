 <!-- Content Start -->
        <div class="content">
            

        <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
<?php /**PATH D:\LaravelProject\IsDB-Laravel\ecommerce-project - Copy\resources\views\layouts\mainContent.blade.php ENDPATH**/ ?>