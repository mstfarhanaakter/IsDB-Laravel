<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection('content'); ?>

<!-- Page Header -->
<div class="text-center mb-4">
    <h4>Update Category</h4>
</div>

<!-- Edit Form Card -->
<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('editStore')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="catagory_id" value="<?php echo e($cat->id); ?>">

            <!-- Name -->
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" required value="<?php echo e($cat->name); ?>">
            </div>

            <!-- Details -->
            <div class="mb-3">
                <label for="details" class="form-label">Details</label>
                <input type="text" name="details" class="form-control" required value="<?php echo e($cat->details); ?>">
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary w-100">Update Category</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LaravelProject\IsDB-Laravel\ecommerce-project - Copy\resources\views\categories\edit.blade.php ENDPATH**/ ?>